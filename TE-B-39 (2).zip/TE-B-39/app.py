from flask import Flask, request, jsonify, render_template
import numpy as np
import joblib
import pandas as pd
from sklearn.preprocessing import OneHotEncoder

# Initialize Flask app
app = Flask(__name__)

# Load the model and encoder
model = joblib.load('model.pkl')


def preprocess_data(df):
    drop_cols = [col for col in ["name", "torque"] if col in df.columns]
    df.drop(columns=drop_cols, inplace=True, errors='ignore')
    df.dropna(inplace=True)
    
    if "mileage" in df.columns:
        df["mileage"] = df["mileage"].astype(str).str.extract(r'(\d+\.\d+|\d+)')[0].astype(float)
    if "engine" in df.columns:
        df["engine"] = df["engine"].astype(str).str.extract(r'(\d+\.\d+|\d+)')[0].astype(float)
    if "max_power" in df.columns:
        df["max_power"] = df["max_power"].astype(str).str.extract(r'(\d+\.\d+|\d+)')[0].astype(float)
    
    categorical_cols = ["fuel", "seller_type", "transmission", "owner"]
    if set(categorical_cols).issubset(df.columns):
        encoded_features = encoder.transform(df[categorical_cols])
        df = df.drop(columns=categorical_cols)
        df = np.hstack((df.values, encoded_features))
    
    return df

# Home route
@app.route('/')
def index():
    return render_template('index.html')

# Prediction route
@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json  # Get data from the frontend
        df = pd.DataFrame([data])
        preprocessed_data = preprocess_data(df)
        X = preprocessed_data[:, 1:]
        prediction = model.predict(X)
        return jsonify({"prediction": prediction[0]})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True)



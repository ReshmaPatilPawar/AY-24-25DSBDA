document.getElementById("predict-form").addEventListener("submit", async function (event) {
    event.preventDefault();

    const fuel = document.getElementById("fuel").value;
    const mileage = document.getElementById("mileage").value;
    const engine = document.getElementById("engine").value;
    const maxPower = document.getElementById("max_power").value;

    const data = {
        fuel: fuel,
        mileage: mileage,
        engine: engine,
        max_power: maxPower,
    };

    try {
        const response = await fetch('/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        const result = await response.json();
        document.getElementById("prediction-result").textContent = result.prediction || result.error;
    } catch (error) {
        document.getElementById("prediction-result").textContent = "Error: " + error.message;
    }
});


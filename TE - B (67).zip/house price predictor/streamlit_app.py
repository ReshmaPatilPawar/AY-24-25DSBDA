import streamlit as st
import pickle
import pandas as pd

# Load the trained model
with open('trained_model.pkl', 'rb') as file:
    model = pickle.load(file)

# Load the feature columns used during training
with open('columns.pkl', 'rb') as f:
    features = pickle.load(f)

# Remove 'SalePrice' and 'Id' from the feature list (not needed for prediction)
features = [feature for feature in features if feature not in ['SalePrice', 'Id']]

# Streamlit app interface
st.set_page_config(page_title="House Price Prediction", page_icon="🏠")
st.title("🏠 House Price Predictor")

st.markdown("""
This application predicts the price of a house based on user-selected features. 
Please select the features you want to provide, and enter their corresponding values.
""")

# Sidebar for feature selection and input
st.sidebar.title("Select Features and Input Values")

# Allow user to select which features to include
selected_features = [feature for feature in features if st.sidebar.checkbox(f"Include {feature}", value=True)]

user_inputs = {}  # Initialize before loop


# Collect user inputs
for feature in selected_features:
    value = st.sidebar.text_input(f"Enter value for {feature}:", placeholder="e.g., 1800")
    if value:
        try:
            user_inputs[feature] = float(value)
        except ValueError:
            st.sidebar.warning(f"Please enter a valid number for {feature}")


# Display input DataFrame
st.subheader("Selected Features and Input Values")
input_df_display = pd.DataFrame(user_inputs, index=[0])
st.write(input_df_display)

# Predict when the button is clicked
if st.sidebar.button("Predict House Price"):
    if len(user_inputs) == 0:
        st.error("Please select at least one feature and provide its value.")
    else:
        # Prepare full input feature set with missing ones filled as 0
        input_features = pd.DataFrame(
            [[user_inputs.get(feature, 0) for feature in features]],
            columns=features
        )

        # Predict
        prediction = model.predict(input_features)
        st.subheader(f"💰 The predicted house price is: ${prediction[0]:,.2f}")

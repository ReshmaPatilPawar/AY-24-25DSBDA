import pickle
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error

# Load your actual data
x_train = pd.read_csv(r'C:\Users\Dell\Desktop\house price predictor\x_train.csv')
y_train = pd.read_csv(r'C:\Users\Dell\Desktop\house price predictor\y_train.csv')

# Remove 'SalePrice' and 'Id' columns
x_train = x_train.drop(columns=['SalePrice', 'Id'], errors='ignore')
y_train = y_train.values.ravel()  # Flatten to 1D

# Train the model using Random Forest Regressor
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(x_train, y_train)

# Save the trained model
with open('trained_model.pkl', 'wb') as file:
    pickle.dump(model, file)

# Save the feature columns for use during prediction
with open('columns.pkl', 'wb') as f:
    pickle.dump(x_train.columns.tolist(), f)

# Optional: Evaluate model
y_pred = model.predict(x_train)
mae = mean_absolute_error(y_train, y_pred)
mse = mean_squared_error(y_train, y_pred)

print("✅ Model trained and saved successfully!")
print(f"📊 Model Evaluation: MAE = {mae:.2f}, MSE = {mse:.2f}")


# 📰 Fake News Detection App

An interactive web application built using **Streamlit** to detect fake news headlines using **TF-IDF Vectorization** and **Logistic Regression**.

---

## 📌 Project Overview

This app allows users to:
- Visualize label distribution of fake and real news.
- Train and evaluate a logistic regression model.
- Predict the truthfulness of custom news headlines.
- View model accuracy, classification report, and confusion matrix.

---

## 📁 Dataset Requirements

Make sure your dataset file is named `NewTask.csv` and is placed in the same directory as the Python script. It must contain at least the following columns:

- `News_Headline`: The text of the news headline.
- `Label`: The corresponding label (e.g., `FAKE`, `REAL` or binary `0`/`1`).

### Example:

| News_Headline                                | Label |
|---------------------------------------------|-------|
| Donald Trump caught in another scandal       | FAKE  |
| Scientists find evidence of water on Mars    | REAL  |

---

## 🛠️ Installation

Ensure you have **Python 3.7+** installed.

1. Clone this repository or download the code.

2. Install required libraries:

```bash
pip install -r requirements.txt
```

### `requirements.txt`

```
streamlit
pandas
matplotlib
seaborn
scikit-learn
```

---

## ▶️ Run the App

In your terminal or command prompt:

```bash
streamlit run app.py
```

This will open the app in your default browser at `http://localhost:8501`.

---

## 🧠 How It Works

1. **Load and Clean Data**
   - Drops missing values from required columns.

2. **Vectorize Text**
   - Uses `TfidfVectorizer` to convert headlines into numerical format.

3. **Train Model**
   - Applies Logistic Regression on 80% training and 20% test data.

4. **Visual Output**
   - Bar chart of label distribution.
   - Confusion matrix and performance metrics.
   - Real-time predictions on custom text input.

---

## 📸 App Features

- **Label Distribution Chart**
- **Model Evaluation**
  - Accuracy
  - Classification Report
  - Confusion Matrix
- **Custom Headline Prediction**

---

## 🔮 Example Use Case

> Enter a news headline like:
>  
> _"NASA confirms presence of water on the moon"_  
>  
> The app will output a predicted label: **REAL** or **FAKE**

---

## 🚀 Future Enhancements

- Add NLP preprocessing (e.g., stopword removal, lemmatization).
- Allow CSV file uploads for bulk prediction.
- Use deep learning models like LSTM or BERT.
- Save and load trained models with joblib/pickle.

---

## 🙌 Acknowledgments

Thanks to open datasets and the power of Streamlit for enabling rapid development of ML-powered web apps.

---

## 📬 Contact

For questions, suggestions, or collaborations, feel free to reach out.

---

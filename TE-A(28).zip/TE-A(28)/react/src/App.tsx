import React, { useState, useRef } from 'react';
import { Upload, ImagePlus, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';

function App() {
  const [image, setImage] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    processImage(file);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processImage(file);
    }
  };

  const processImage = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImage(e.target?.result as string);
        // Simulate API call
        setLoading(true);
        setTimeout(() => {
          setResult(Math.random() > 0.5 ? 'positive' : 'negative');
          setLoading(false);
        }, 2000);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Pneumonia Detection</h1>
          <p className="text-gray-600">Upload a chest X-ray image for pneumonia detection</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Upload Section */}
          <div 
            className={`border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center min-h-[300px] transition-colors ${
              isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            {!image ? (
              <>
                <ImagePlus className="w-12 h-12 text-gray-400 mb-4" />
                <p className="text-gray-600 text-center mb-4">
                  Drag and drop your X-ray image here, or click to select
                </p>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors flex items-center gap-2"
                >
                  <Upload className="w-4 h-4" />
                  Upload Image
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileInput}
                  accept="image/*"
                  className="hidden"
                />
              </>
            ) : (
              <img
                src={image}
                alt="Uploaded X-ray"
                className="max-h-[300px] object-contain"
              />
            )}
          </div>

          {/* Results Section */}
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h2 className="text-xl font-semibold mb-4">Analysis Results</h2>
            {loading ? (
              <div className="flex items-center justify-center h-[200px]">
                <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
              </div>
            ) : result ? (
              <div className="space-y-4">
                <div className={`flex items-center gap-2 ${
                  result === 'positive' ? 'text-red-500' : 'text-green-500'
                }`}>
                  {result === 'positive' ? (
                    <AlertCircle className="w-5 h-5" />
                  ) : (
                    <CheckCircle2 className="w-5 h-5" />
                  )}
                  <span className="font-medium capitalize">
                    {result === 'positive' ? 'Pneumonia Detected' : 'No Pneumonia Detected'}
                  </span>
                </div>
                <p className="text-gray-600">
                  {result === 'positive' 
                    ? 'The analysis indicates signs of pneumonia. Please consult with a healthcare professional for proper diagnosis.'
                    : 'The analysis shows no significant signs of pneumonia. However, always consult with a healthcare professional for proper medical advice.'}
                </p>
              </div>
            ) : (
              <div className="text-gray-500 text-center h-[200px] flex items-center justify-center">
                <p>Upload an image to see the results</p>
              </div>
            )}
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-8 text-sm text-gray-500 text-center">
          <p>This tool is for demonstration purposes only and should not be used for actual medical diagnosis.</p>
          <p>Always consult with qualified healthcare professionals for medical advice.</p>
        </div>
      </div>
    </div>
  );
}

export default App;
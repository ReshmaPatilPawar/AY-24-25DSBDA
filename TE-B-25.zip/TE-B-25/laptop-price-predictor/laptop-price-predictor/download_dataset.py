import kagglehub
path = kagglehub.dataset_download("jacksondivakarr/laptop-price-prediction-dataset")
print("✅ Path to dataset files:", path)

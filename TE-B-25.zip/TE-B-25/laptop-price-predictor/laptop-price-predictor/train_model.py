import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
import pickle
import matplotlib.pyplot as plt
import joblib

# Load the dataset
df = pd.read_csv('data.csv')

# Drop unnecessary columns
df = df.drop(['Unnamed: 0', 'name'], axis=1)

# Clean and convert RAM
df['Ram'] = df['Ram'].str.replace('GB', '', regex=False).astype(int)

# Clean and convert ROM (GB or TB to int)
df['ROM'] = df['ROM'].str.replace('GB', '', regex=False)
df['ROM'] = df['ROM'].str.replace('TB', '000', regex=False)
df['ROM'] = df['ROM'].astype(int)

# Convert resolution columns
df['resolution_width'] = df['resolution_width'].astype(int)
df['resolution_height'] = df['resolution_height'].astype(int)

# Convert display size to float
df['display_size'] = df['display_size'].astype(float)

# Calculate PPI (Pixels Per Inch)
df['PPI'] = (np.sqrt(df['resolution_width']**2 + df['resolution_height']**2)) / df['display_size']

# Drop raw resolution columns as PPI is more informative
df = df.drop(['resolution_width', 'resolution_height'], axis=1)

# Encode categorical variables
categorical_cols = ['brand', 'processor', 'CPU', 'Ram_type', 'ROM_type', 'GPU', 'OS', 'warranty']
df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)

# Prepare features (X) and target (y)
X = df.drop('price', axis=1)
joblib.dump(X.columns.tolist(), 'columns.pkl')
y = df['price']

# Scale the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split data into train-test sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Initialize and train the model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict on training and testing data
y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)

# Evaluate the model
train_score = model.score(X_train, y_train)
test_score = model.score(X_test, y_test)

# Print accuracy
print(f"Train Accuracy (R²): {train_score:.4f}")
print(f"Test Accuracy (R²): {test_score:.4f}")

# Save model to file
with open('model.pkl', 'wb') as f:
    pickle.dump(model, f)

# Save scaler to file
with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

# Save accuracies
accuracies = {
    'train_accuracy': train_score,
    'test_accuracy': test_score
}
with open('accuracies.pkl', 'wb') as f:
    pickle.dump(accuracies, f)

# Plot Actual vs Predicted
plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_test_pred, color='blue')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], color='red', lw=2)
plt.xlabel('Actual Price')
plt.ylabel('Predicted Price')
plt.title('Actual vs Predicted Prices')
plt.savefig('static/actual_vs_predicted.png')
plt.show()

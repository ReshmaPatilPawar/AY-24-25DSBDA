from flask import Flask, request, jsonify, send_from_directory, render_template_string
import pickle
import numpy as np
import pandas as pd
import joblib

app = Flask(__name__)

# Load the trained model and scaler
model = pickle.load(open('model.pkl', 'rb'))
scaler = pickle.load(open('scaler.pkl', 'rb'))

# Load accuracy scores (from .pkl instead of .json)
with open('accuracies.pkl', 'rb') as f:
    accuracy_data = pickle.load(f)

# Serve the index.html file
@app.route('/')
def index():
    with open('templates/index.html') as f:
        return render_template_string(f.read())

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    # Calculate PPI
    resolution_width = float(data['resolution_width'])
    resolution_height = float(data['resolution_height'])
    display_size = float(data['display_size'])
    ppi = (np.sqrt(resolution_width**2 + resolution_height**2)) / display_size

    features = [
        float(data['ram']),
        float(data['rom']),
        display_size,
        ppi,
        float(data['warranty']),
    ]

    input_df = pd.DataFrame([features], columns=['Ram', 'ROM', 'display_size', 'PPI', 'warranty'])

    # Scale the input
    columns = joblib.load('columns.pkl')  # Load expected columns

    # One-hot encode user input like before
    input_df = pd.get_dummies(input_df)

    # Add missing columns
    for col in columns:
        if col not in input_df:
            input_df[col] = 0

    # Remove unexpected columns
    input_df = input_df[columns]

    # Now safe to scale
    scaled_input = scaler.transform(input_df)

    # Predict the price
    prediction = model.predict(scaled_input)[0]

    return jsonify({'predicted_price': round(prediction, 2)})

@app.route('/accuracy_data.json')
def get_accuracy():
    return jsonify(accuracy_data)

@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

if __name__ == '__main__':
    app.run(debug=True)

from flask import Flask, render_template, request
import joblib

app = Flask(__name__)

# Load the trained model
model = joblib.load('mood_model.pkl')

# Define mood labels
mood_labels = {
    0: 'Angry 😠',
    1: 'Sad 😞',
    2: 'Happy 😄'
}

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None
    if request.method == 'POST':
        sleep = float(request.form['sleep'])
        exercise = float(request.form['exercise'])
        water = float(request.form['water'])
        stress = float(request.form['stress'])

        input_data = [[sleep, exercise, water, stress]]
        pred_num = model.predict(input_data)[0]

        # Convert number to label
        prediction = mood_labels.get(pred_num, "Unknown 🤔")

    return render_template('index.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)

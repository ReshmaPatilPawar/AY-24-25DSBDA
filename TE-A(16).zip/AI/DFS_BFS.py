from collections import defaultdict, deque


class Graph:
    def __init__(self):
        self.graph = defaultdict(list)


    def add_edge(self, u, v):
        self.graph[u].append(v)
        self.graph[v].append(u)

   
    def dfs_recursive(self, node, visited=None):
        if visited is None:
            visited = set()
        visited.add(node)
        print(node, end=" ")

        for neighbor in self.graph[node]:
            if neighbor not in visited:
                self.dfs_recursive(neighbor, visited)

 
    def bfs(self, start_node):
        visited = set()
        queue = deque([start_node])
        visited.add(start_node)

        while queue:
            node = queue.popleft()
            print(node, end=" ")
            for neighbor in self.graph[node]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)


g = Graph()
edges = [
    (0, 4), (0, 2), (1, 3), (1, 4),
    (2, 5), (2, 6)
]

for u, v in edges:
    g.add_edge(u, v)

print("DFS Traversal (Recursive):")
g.dfs_recursive(0)

print("\nBFS Traversal (Using Queue):")
g.bfs(0)

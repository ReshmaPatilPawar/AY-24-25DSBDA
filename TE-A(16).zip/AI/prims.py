import heapq

def prim(graph, start):
    visited = set()
    min_heap = [(0, start)]
    mst_weight = 0
    mst_edges = []

    while min_heap:
        weight, current = heapq.heappop(min_heap)
        if current in visited:
            continue
        visited.add(current)
        mst_weight += weight

        if weight != 0:
            mst_edges.append((current, weight))

        for neighbor, edge_weight in graph[current]:
            if neighbor not in visited:
                heapq.heappush(min_heap, (edge_weight, neighbor))

    return mst_edges, mst_weight


graph = {
    'A': [('B', 1), ('C', 4)],
    'B': [('A', 1), ('C', 2), ('D', 6)],
    'C': [('A', 4), ('B', 2), ('D', 3)],
    'D': [('B', 6), ('C', 3)]
}

edges, total_weight = prim(graph, 'A')
print("Edges in MST:")
for node, weight in edges:
    print(f"{node} with edge weight {weight}")
print(f"Total weight of MST: {total_weight}")

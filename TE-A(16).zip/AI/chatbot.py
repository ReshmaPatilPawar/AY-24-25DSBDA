class Chatbot:
    def __init__(self):
        self.responses = {
            "greet": "Hello! How can I assist you today?",
            "order_status": "Please provide your order ID to check the status.",
            "order_tracking": "You can track your order using the tracking number provided in the confirmation email.",
            "return_policy": "You can return items within 30 days of purchase, as long as they are in original condition.",
            "thank_you": "You're welcome! If you have any other questions, feel free to ask.",
            "bye": "Goodbye! Have a great day!",
        }

    def greet(self):
        return self.responses["greet"]

    def order_status(self):
        return self.responses["order_status"]

    def order_tracking(self):
        return self.responses["order_tracking"]

    def return_policy(self):
        return self.responses["return_policy"]

    def thank_you(self):
        return self.responses["thank_you"]

    def bye(self):
        return self.responses["bye"]

    def get_response(self, user_input):
        if "hi" in user_input.lower() or "hello" in user_input.lower():
            return self.greet()
        elif "order status" in user_input.lower():
            return self.order_status()
        elif "track order" in user_input.lower():
            return self.order_tracking()
        elif "return policy" in user_input.lower():
            return self.return_policy()
        elif "thank you" in user_input.lower():
            return self.thank_you()
        elif "bye" in user_input.lower():
            return self.bye()
        else:
            return "I'm sorry, I didn't understand that. Can you please rephrase?"

def chat():
    bot = Chatbot()
    print("Customer Support Chatbot: Hello! Type 'bye' to end the conversation.")
    
    while True:
        user_input = input("You: ")
        if "bye" in user_input.lower():
            print("Customer Support Chatbot:", bot.bye())
            break
        response = bot.get_response(user_input)
        print("Customer Support Chatbot:", response)


chat()

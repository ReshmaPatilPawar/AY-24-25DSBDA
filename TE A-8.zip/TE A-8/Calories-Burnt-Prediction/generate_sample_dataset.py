import numpy as np
import pandas as pd

np.random.seed(42)

data = {
    'Age': np.random.randint(18, 60, 100),
    'Height': np.random.randint(150, 190, 100),
    'Weight': np.random.randint(50, 100, 100),
    'Duration': np.random.randint(10, 60, 100),
    'Heart_Rate': np.random.randint(70, 160, 100),
    'Body_Temp': np.round(np.random.normal(98.6, 0.7, 100), 1),
    'Gender': np.random.choice([0, 1], 100),
}

df = pd.DataFrame(data)

df['Calories_Burnt'] = (
    df['Duration'] * (df['Heart_Rate'] / 100) + 
    df['Weight'] * 0.2 - 
    df['Age'] * 0.5 + 
    np.random.randint(50, 150, 100)
)

df['Calories_Burnt'] = df['Calories_Burnt'].clip(100, 800)

df.to_csv('calories.csv', index=False)
print("✅ calories.csv file generated successfully.")

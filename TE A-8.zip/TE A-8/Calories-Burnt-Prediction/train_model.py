from sklearn.ensemble import RandomForestRegressor
import pickle

data = pd.read_csv('calories.csv')

X = data[['Age', 'Height', 'Weight', 'Duration', 'Heart_Rate', 'Body_Temp', 'Gender']]
y = data['Calories_Burnt']

model = RandomForestRegressor()
model.fit(X, y)

with open('calories_model.pkl', 'wb') as f:
    pickle.dump(model, f)

print("✅ Model trained and saved as 'calories_model.pkl'")

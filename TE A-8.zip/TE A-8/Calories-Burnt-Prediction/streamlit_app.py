import streamlit as st
import pandas as pd
import joblib
import os
import pickle

@st.cache_data
def load_model():
    try:
        with open('calories_model.pkl', 'rb') as file:
            loaded_model = joblib.load(file)
        return loaded_model
    except FileNotFoundError:
        st.error("Model file 'calories_model.pkl' not found. Please train the model first.")
        return None

loaded_model = load_model()

st.sidebar.title('Navigation')
options = st.sidebar.selectbox('Select a page:', 
                               ['Prediction', 'Code', 'About'])

if options == 'Prediction':
    st.title('🔥 Calories Burnt Prediction Web App')

    gender = st.selectbox('Gender', ['Male', 'Female'])
    age = st.number_input('Age', min_value=1, max_value=100, value=25)
    height = st.number_input('Height (cm)', min_value=100, max_value=250, value=170)
    weight = st.number_input('Weight (kg)', min_value=30, max_value=200, value=70)
    duration = st.number_input('Workout Duration (min)', min_value=1, max_value=180, value=60)
    heart_rate = st.number_input('Heart Rate (bpm)', min_value=60, max_value=200, value=100)
    body_temp = st.number_input('Body Temperature (°C)', min_value=35.0, max_value=43.0, value=37.0)

    user_inputs = {
        'Age': age,  
        'Height': height,
        'Weight': weight,
        'Duration': duration,
        'Heart_Rate': heart_rate,
        'Body_Temp': body_temp,  
        'Gender': 0 if gender == 'Male' else 1  
    }

    input_df = pd.DataFrame([user_inputs])
    expected_columns = ['Age', 'Height', 'Weight', 'Duration', 'Heart_Rate', 'Body_Temp', 'Gender']
    input_df = input_df[expected_columns]

    if st.button('Predict'):
        if loaded_model:
            prediction = loaded_model.predict(input_df)
            st.success(f'✅ Estimated Calories Burnt: **{prediction[0]:,.2f}**')
            with st.expander("🔍 Show Model Info"):
                st.write('Model used: **Random Forest Regressor**')
        else:
            st.error("Model not loaded. Please check the model file.")

elif options == 'Code':
    st.header('📄 Code Files')
    
    notebook_path = 'calories_burnt_prediction.ipynb'
    if os.path.exists(notebook_path):
        with open(notebook_path, "rb") as file:
            st.download_button(
                label="📥 Download Jupyter Notebook",
                data=file,
                file_name="calories_burnt_prediction.ipynb",
                mime="application/x-ipynb+json"
            )
    else:
        st.warning("Notebook file not found.")

    st.header('📊 Dataset')
    data_path = 'calories.csv'
    if os.path.exists(data_path):
        with open(data_path, "rb") as file:
            st.download_button(
                label="📥 Download Dataset",
                data=file,
                file_name="calories.csv",
                mime="text/csv"
            )
    else:
        st.warning("Dataset file not found.")

elif options == 'About':
    st.title('📘 About This App')
    st.write("""
    This web app predicts **Calories Burnt** based on various inputs like gender, age, height, weight,
    workout duration, heart rate, and body temperature.

    **Model Used:** Random Forest Regressor  
    **Dataset Source:** [Kaggle Dataset](https://www.kaggle.com/datasets/fmendes/fmendesdat263xdemos)

    Created with ❤️ using **Python, Streamlit, and Machine Learning**.
    """)

from flask import Flask, render_template, request
import numpy as np
import pickle

app = Flask(__name__)

# Load the model
model = pickle.load(open('Medical Insurance Cost Prediction.pkl', 'rb'))
print("Model", type(model))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get form values
    age = float(request.form['age'])
    bmi = float(request.form['bmi'])
    children = int(request.form['children'])
    smoker = 1 if request.form['smoker'] == 'yes' else 0
    gender = 1 if request.form['gender'] == 'male' else 0
    region = int(request.form['region'])  # or however it was encoded during training

    input_data = np.array([[age, bmi, children, smoker, gender, region]])
    prediction = model.predict(input_data)[0]
    
    return render_template('index.html', prediction_text=f"Estimated Insurance Cost: ${prediction:.2f}")

if __name__ == '__main__':
    app.run(debug=True)

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

st.set_page_config(page_title="Netflix Classifier", layout="wide")

# Load data
@st.cache_data
def load_data():
    return pd.read_csv("netflix_titles.csv")

df = load_data()

# Sidebar - Search
st.sidebar.header("🔍 Search Netflix Title")
search_query = st.sidebar.text_input("Enter movie or show title")

if search_query:
    filtered = df[df["title"].str.contains(search_query, case=False, na=False)]
    st.subheader(f"Search Results for: *{search_query}*")
    if not filtered.empty:
        st.dataframe(filtered[["title", "type", "director", "cast", "country", "release_year", "duration", "listed_in", "description"]])
    else:
        st.warning("No matching titles found.")

# Sidebar - Dataset view
st.sidebar.header("🗂 Data View Options")
show_data = st.sidebar.checkbox("Show Netflix Dataset")

# Data Preprocessing
df.dropna(subset=["type", "release_year", "duration"], inplace=True)
df["duration"] = df["duration"].astype(str)

def convert_duration(duration_str):
    if "Season" in duration_str:
        try:
            seasons = int(duration_str.split()[0])
            return seasons * 60  # Approx 60 min per season
        except:
            return 60
    elif "min" in duration_str:
        try:
            return int(duration_str.split()[0])
        except:
            return 0
    else:
        return 0

df["duration_num"] = df["duration"].apply(convert_duration)

# Encode type
le_type = LabelEncoder()
df["type_encoded"] = le_type.fit_transform(df["type"])  # 0 = Movie, 1 = TV Show

# Feature setup
features = ["release_year", "duration_num"]
X = df[features]
y = df["type_encoded"]

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Prediction display
st.sidebar.header("📊 Prediction Options")
data_option = st.sidebar.selectbox("Choose data for prediction", ["Training Data", "Testing Data"])

if data_option == "Training Data":
    y_pred = model.predict(X_train)
    st.subheader("📘 Predictions on Training Data")
    st.write("✅ Accuracy:", round(accuracy_score(y_train, y_pred), 2))
    st.text(classification_report(y_train, y_pred, target_names=le_type.classes_))

elif data_option == "Testing Data":
    y_pred = model.predict(X_test)
    st.subheader("📗 Predictions on Testing Data")
    st.write("✅ Accuracy:", round(accuracy_score(y_test, y_pred), 2))
    st.text(classification_report(y_test, y_pred, target_names=le_type.classes_))

# Manual prediction (fixed)
st.sidebar.header("🎯 Try Manual Prediction")
year = st.sidebar.number_input("Release Year", min_value=1900, max_value=2025, value=2020)
duration_type = st.sidebar.selectbox("Content Format", ["Movie (in minutes)", "TV Show (in seasons)"])

if duration_type == "Movie (in minutes)":
    duration_value = st.sidebar.number_input("Duration (minutes)", min_value=1, max_value=300, value=90)
else:
    seasons = st.sidebar.number_input("No. of Seasons", min_value=1, max_value=20, value=1)
    duration_value = seasons * 60

if st.sidebar.button("Predict Type"):
    user_input = pd.DataFrame([[year, duration_value]], columns=features)
    prediction = model.predict(user_input)
    predicted_label = le_type.inverse_transform(prediction)[0]
    st.sidebar.success(f"📢 Predicted Content Type: **{predicted_label}**")

# Show full dataset
if show_data:
    st.subheader("📄 Netflix Dataset (Full View)")
    st.dataframe(df)

# ===================
# 📊 Visualizations
# ===================
st.header("📈 Data Visualizations")

# 1. Pie chart
st.subheader("Content Type Distribution")
fig1, ax1 = plt.subplots()
type_counts = df["type"].value_counts()
ax1.pie(type_counts, labels=type_counts.index, autopct='%1.1f%%', startangle=90, colors=["skyblue", "lightgreen"])
ax1.axis('equal')
st.pyplot(fig1)

# 2. Histogram
st.subheader("Titles Released Over the Years")
fig2, ax2 = plt.subplots()
sns.histplot(df["release_year"], bins=30, kde=False, color="coral", ax=ax2)
ax2.set_xlabel("Release Year")
ax2.set_ylabel("Number of Titles")
st.pyplot(fig2)

# 3. Scatter plot
st.subheader("Scatter Plot: Release Year vs Duration (Colored by Type)")
fig3, ax3 = plt.subplots()
sns.scatterplot(x="release_year", y="duration_num", hue="type", data=df, palette="Set2", ax=ax3)
ax3.set_xlabel("Release Year")
ax3.set_ylabel("Duration (minutes)")
st.pyplot(fig3)

# 4. Feature importance
st.subheader("Feature Importance from Random Forest")
feat_imp = pd.Series(model.feature_importances_, index=features)
fig4, ax4 = plt.subplots()
feat_imp.plot(kind='barh', color='mediumpurple', ax=ax4)
ax4.set_xlabel("Importance Score")
st.pyplot(fig4)
